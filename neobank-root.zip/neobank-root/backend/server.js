require('dotenv').config();
const http = require('http');
const { Server } = require('socket.io');
const app = require('./src/app');
const initSockets = require('./src/sockets');
const { startCronJobs } = require('./src/services/cronService');

const PORT = process.env.PORT || 4000;
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:5173', credentials: true },
});

initSockets(io);
app.set('io', io); // accessible depuis les contrôleurs via req.app.get('io')

startCronJobs(io);

server.listen(PORT, () => {
  console.log(`✅ NeoBank API démarrée sur http://localhost:${PORT}`);
  console.log(`🔌 WebSocket temps réel actif`);
});
