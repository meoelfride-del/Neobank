const db = require('../config/database');

function listUsers(req, res) {
  const users = db.prepare(`
    SELECT id, nom, prenom, email, phone, role, status_kyc, status_compte, fraud_score, created_at
    FROM users ORDER BY created_at DESC
  `).all();
  res.json({ users });
}

function getStats(req, res) {
  const totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  const pendingKyc = db.prepare(`SELECT COUNT(*) as c FROM users WHERE status_kyc IN ('pending','in_review')`).get().c;
  const suspended = db.prepare(`SELECT COUNT(*) as c FROM users WHERE status_compte = 'suspended'`).get().c;
  const flaggedTx = db.prepare(`SELECT COUNT(*) as c FROM transactions WHERE status = 'pending'`).get().c;
  const totalBalance = db.prepare('SELECT COALESCE(SUM(balance),0) as s FROM accounts').get().s;

  res.json({ totalUsers, pendingKyc, suspended, flaggedTx, totalBalance });
}

function validateKyc(req, res) {
  const { userId } = req.params;
  const { decision } = req.body; // 'verified' | 'rejected'
  if (!['verified', 'rejected'].includes(decision)) {
    return res.status(422).json({ error: 'Décision invalide.' });
  }
  db.prepare('UPDATE users SET status_kyc = ? WHERE id = ?').run(decision, userId);
  logAudit(req.user.id, 'kyc_review', `user=${userId} decision=${decision}`);
  res.json({ message: `KYC ${decision === 'verified' ? 'validé' : 'rejeté'}.` });
}

function suspendUser(req, res) {
  const { userId } = req.params;
  const { suspended } = req.body;
  db.prepare('UPDATE users SET status_compte = ? WHERE id = ?').run(suspended ? 'suspended' : 'active', userId);
  logAudit(req.user.id, 'account_suspend', `user=${userId} suspended=${suspended}`);
  res.json({ message: suspended ? 'Compte suspendu.' : 'Compte réactivé.' });
}

function pendingTransactions(req, res) {
  const transactions = db.prepare(`
    SELECT t.*, a.iban, u.email, u.fraud_score FROM transactions t
    JOIN accounts a ON t.source_account_id = a.id
    JOIN users u ON a.user_id = u.id
    WHERE t.status = 'pending'
    ORDER BY t.timestamp DESC
  `).all();
  res.json({ transactions });
}

function reviewTransaction(req, res) {
  const { txId } = req.params;
  const { approve } = req.body;

  const runReview = db.transaction(() => {
    const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(txId);
    if (!tx) throw new Error('not_found');

    if (approve) {
      db.prepare(`UPDATE transactions SET status = 'completed' WHERE id = ?`).run(txId);
    } else {
      db.prepare(`UPDATE transactions SET status = 'failed' WHERE id = ?`).run(txId);
      // Remboursement du compte source
      db.prepare('UPDATE accounts SET balance = balance - ? WHERE id = ?').run(tx.amount, tx.source_account_id);
    }
  });

  try {
    runReview();
    logAudit(req.user.id, 'tx_review', `tx=${txId} approve=${approve}`);
    res.json({ message: approve ? 'Transaction validée.' : 'Transaction rejetée et remboursée.' });
  } catch (err) {
    res.status(404).json({ error: 'Transaction introuvable.' });
  }
}

function logAudit(userId, action, details) {
  const { v4: uuid } = require('uuid');
  db.prepare('INSERT INTO audit_logs (id, user_id, action, details) VALUES (?, ?, ?, ?)').run(uuid(), userId, action, details);
}

module.exports = { listUsers, getStats, validateKyc, suspendUser, pendingTransactions, reviewTransaction };
