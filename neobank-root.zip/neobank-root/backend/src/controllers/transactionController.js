const { v4: uuid } = require('uuid');
const db = require('../config/database');
const { categorize } = require('../services/budgetService');
const { computeFraudScore, requiresManualReview } = require('../services/fraudService');

function listTransactions(req, res) {
  const { accountId } = req.params;
  const transactions = db.prepare(`
    SELECT * FROM transactions WHERE source_account_id = ? ORDER BY timestamp DESC LIMIT 200
  `).all(accountId);
  res.json({ transactions });
}

/**
 * Virement instantané interne ou externe.
 * Logique transactionnelle stricte (ACID) : débit source + crédit destination
 * (si compte interne) exécutés dans une seule transaction SQLite atomique.
 * Si une étape échoue, l'ensemble est annulé (rollback automatique).
 */
function transfer(req, res, next) {
  const { source_account_id, destination_type, destination_info, amount, libelle } = req.body;
  const io = req.app.get('io');

  try {
    const runTransfer = db.transaction(() => {
      const source = db.prepare('SELECT * FROM accounts WHERE id = ?').get(source_account_id);
      if (!source) throw httpError(404, 'Compte source introuvable.');
      if (source.user_id !== req.user.id) throw httpError(403, 'Ce compte ne vous appartient pas.');
      if (source.balance < amount) throw httpError(400, 'Solde insuffisant.');

      // --- Score de fraude (règles simulant un moteur ML) ---
      const recentTxCount = db.prepare(`
        SELECT COUNT(*) as c FROM transactions
        WHERE source_account_id = ? AND timestamp > datetime('now', '-1 hour')
      `).get(source_account_id).c;

      const existingDest = db.prepare(`
        SELECT COUNT(*) as c FROM transactions
        WHERE source_account_id = ? AND destination_info = ?
      `).get(source_account_id, destination_info).c;

      const accountAgeDays = db.prepare(`
        SELECT CAST(julianday('now') - julianday(created_at) AS INTEGER) as age FROM accounts WHERE id = ?
      `).get(source_account_id).age;

      const fraudScore = computeFraudScore({
        amount,
        recentTxCount,
        isNewDestination: existingDest === 0,
        accountAgeDays,
      });

      const flagged = requiresManualReview(fraudScore);
      const category = categorize(libelle || '');
      const txId = uuid();

      // Débit du compte source
      db.prepare('UPDATE accounts SET balance = balance - ? WHERE id = ?').run(amount, source_account_id);

      db.prepare(`
        INSERT INTO transactions (id, source_account_id, destination_info, amount, type, category, status, libelle)
        VALUES (?, ?, ?, ?, 'virement_interne', ?, ?, ?)
      `).run(txId, source_account_id, destination_info, -amount, category, flagged ? 'pending' : 'completed', libelle || '');

      // Recherche du destinataire interne (par téléphone ou IBAN)
      let destAccount = null;
      if (!flagged) {
        if (destination_type === 'phone') {
          const destUser = db.prepare('SELECT id FROM users WHERE phone = ?').get(destination_info);
          if (destUser) {
            destAccount = db.prepare(`SELECT * FROM accounts WHERE user_id = ? AND type = 'Courant'`).get(destUser.id);
          }
        } else {
          destAccount = db.prepare('SELECT * FROM accounts WHERE iban = ?').get(destination_info);
        }

        if (destAccount) {
          db.prepare('UPDATE accounts SET balance = balance + ? WHERE id = ?').run(amount, destAccount.id);
          db.prepare(`
            INSERT INTO transactions (id, source_account_id, destination_info, amount, type, category, status, libelle)
            VALUES (?, ?, ?, ?, 'depot', 'Autre', 'completed', ?)
          `).run(uuid(), destAccount.id, source.iban, amount, libelle || `Virement de ${source.iban}`);
        }
      }

      // Score de fraude élevé -> compte suspendu automatiquement pour revue
      if (flagged) {
        db.prepare('UPDATE users SET fraud_score = ? WHERE id = ?').run(fraudScore, req.user.id);
      }

      const updatedSource = db.prepare('SELECT * FROM accounts WHERE id = ?').get(source_account_id);
      return { txId, updatedSource, destAccount, flagged, fraudScore };
    });

    const result = runTransfer();

    // Notification temps réel via WebSocket
    if (io) {
      io.to(`user:${req.user.id}`).emit('balance:update', { accountId: result.updatedSource.id, balance: result.updatedSource.balance });
      if (result.destAccount) {
        io.to(`user:${result.destAccount.user_id}`).emit('balance:update', { accountId: result.destAccount.id, balance: result.destAccount.balance });
        io.to(`user:${result.destAccount.user_id}`).emit('transaction:new', { message: 'Nouveau virement reçu' });
      }
    }

    res.status(201).json({
      message: result.flagged
        ? 'Virement en attente de vérification manuelle (activité inhabituelle détectée).'
        : 'Virement effectué avec succès.',
      transactionId: result.txId,
      newBalance: result.updatedSource.balance,
      flagged: result.flagged,
    });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.publicMessage });
    next(err);
  }
}

function httpError(status, publicMessage) {
  const e = new Error(publicMessage);
  e.status = status;
  e.publicMessage = publicMessage;
  return e;
}

function createScheduledPayment(req, res, next) {
  try {
    const { account_id, destination_info, amount, label, frequency } = req.body;
    const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(account_id);
    if (!account || account.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Ce compte ne vous appartient pas.' });
    }

    const id = uuid();
    const nextRun = new Date();
    nextRun.setDate(nextRun.getDate() + (frequency === 'hebdomadaire' ? 7 : 30));

    db.prepare(`
      INSERT INTO scheduled_payments (id, account_id, destination_info, amount, label, frequency, next_run)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, account_id, destination_info, amount, label, frequency, nextRun.toISOString());

    res.status(201).json({ message: 'Prélèvement automatique programmé (signature électronique validée).', id });
  } catch (err) {
    next(err);
  }
}

function listScheduledPayments(req, res) {
  const { accountId } = req.params;
  const payments = db.prepare('SELECT * FROM scheduled_payments WHERE account_id = ?').all(accountId);
  res.json({ payments });
}

module.exports = { listTransactions, transfer, createScheduledPayment, listScheduledPayments };
