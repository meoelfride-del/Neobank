const router = require('express').Router();
const ctrl = require('../controllers/adminController');
const { authenticate, requireRole } = require('../middleware/auth');

router.use(authenticate, requireRole('admin'));
router.get('/users', ctrl.listUsers);
router.get('/stats', ctrl.getStats);
router.post('/kyc/:userId', ctrl.validateKyc);
router.post('/users/:userId/suspend', ctrl.suspendUser);
router.get('/transactions/pending', ctrl.pendingTransactions);
router.post('/transactions/:txId/review', ctrl.reviewTransaction);

module.exports = router;
