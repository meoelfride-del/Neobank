import { create } from 'zustand';
import api from '../services/api';
import { connectSocket, disconnectSocket } from '../services/socket';

const useAuthStore = create((set, get) => ({
  user: JSON.parse(localStorage.getItem('neobank_user') || 'null'),
  isAuthenticated: !!localStorage.getItem('neobank_access_token'),
  loading: false,
  error: null,
  mfaRequired: false,

  async login(email, password, otp) {
    set({ loading: true, error: null, mfaRequired: false });
    try {
      const { data } = await api.post('/auth/login', { email, password, otp });
      localStorage.setItem('neobank_access_token', data.accessToken);
      localStorage.setItem('neobank_refresh_token', data.refreshToken);
      localStorage.setItem('neobank_user', JSON.stringify(data.user));
      set({ user: data.user, isAuthenticated: true, loading: false });
      connectSocket();
      return { success: true };
    } catch (err) {
      if (err.response?.status === 206 && err.response.data?.mfaRequired) {
        set({ mfaRequired: true, loading: false });
        return { success: false, mfaRequired: true };
      }
      const message = err.response?.data?.error || 'Erreur de connexion.';
      set({ error: message, loading: false });
      return { success: false, error: message };
    }
  },

  async register(payload) {
    set({ loading: true, error: null });
    try {
      const { data } = await api.post('/auth/register', payload);
      localStorage.setItem('neobank_access_token', data.accessToken);
      localStorage.setItem('neobank_refresh_token', data.refreshToken);
      localStorage.setItem('neobank_user', JSON.stringify(data.user));
      set({ user: data.user, isAuthenticated: true, loading: false });
      connectSocket();
      return { success: true, mfaSetup: data.mfaSetup };
    } catch (err) {
      const message = err.response?.data?.details?.join(' ') || err.response?.data?.error || "Erreur lors de l'inscription.";
      set({ error: message, loading: false });
      return { success: false, error: message };
    }
  },

  async refreshUser() {
    try {
      const { data } = await api.get('/auth/me');
      localStorage.setItem('neobank_user', JSON.stringify(data.user));
      set({ user: data.user });
    } catch {
      /* silencieux : l'intercepteur gère le refresh/logout */
    }
  },

  logout() {
    localStorage.removeItem('neobank_access_token');
    localStorage.removeItem('neobank_refresh_token');
    localStorage.removeItem('neobank_user');
    disconnectSocket();
    set({ user: null, isAuthenticated: false });
  },

  clearError() {
    set({ error: null, mfaRequired: false });
  },
}));

export default useAuthStore;
