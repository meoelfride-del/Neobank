# NeoBank — Plateforme Bancaire Full-Stack

Application complète construite selon le plan d'architecture NeoBank Enterprise :
**React (Vite) + Node.js/Express + SQLite + Socket.io**, avec authentification forte (SCA/2FA),
multi-comptes, virements instantanés, cartes virtuelles/physiques, budget intelligent (PFM),
chatbot IA, et back-office administrateur (RBAC).

> Les services tiers (KYC/Sumsub, Chatbot/OpenAI, Open Banking/Plaid) sont **simulés** pour
> fonctionner sans clé API — voir `backend/src/services/` pour brancher de vrais fournisseurs.

## 🚀 Démarrage rapide

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
npm run seed     # crée un admin + un client de démonstration
npm run dev       # démarre l'API sur http://localhost:4000 (nodemon)
```

Comptes de démonstration créés par `npm run seed` :
- **Client** : `client@neobank.demo` / `Client123!`
- **Admin** : `admin@neobank.demo` / `Admin123!`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev        # démarre sur http://localhost:5173 (proxy /api -> :4000)
```

Ouvrez http://localhost:5173 — connectez-vous avec un des comptes ci-dessus.

## 🏗️ Structure du projet

```
neobank-root/
├── backend/
│   ├── src/
│   │   ├── config/        # SQLite (database.js), script de seed
│   │   ├── controllers/   # Auth, Accounts, Transactions, Cards, Budget, Chatbot, Admin
│   │   ├── middleware/    # JWT auth, RBAC, validation Joi, gestion d'erreurs
│   │   ├── models/        # (schéma défini directement dans database.js)
│   │   ├── services/      # crypto (AES-256-GCM), fraude, KYC mock, chatbot mock, cron, budget
│   │   ├── routes/        # Déclaration des endpoints REST
│   │   └── sockets/       # WebSocket temps réel (soldes, transactions, chat)
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/    # Sidebar, Navbar, CardVisual, TransactionRow, BudgetChart...
│   │   ├── views/         # Login, Register, Onboarding, Dashboard, Accounts, Transfer...
│   │   ├── store/         # Zustand : authStore, accountStore
│   │   ├── services/      # api.js (Axios + intercepteurs refresh), socket.js
│   │   ├── App.jsx        # Routing (react-router-dom)
│   │   └── main.jsx
│   └── package.json
└── README.md
```

## 🔐 Sécurité implémentée

- **JWT** access token (15 min) + refresh token (7 jours), rafraîchissement automatique côté client.
- **SCA/2FA** : TOTP (otplib), compatible Google Authenticator — activable via `/api/auth/mfa/enable`.
- **RBAC** : middleware `requireRole('admin')` sur toutes les routes `/api/admin/*`.
- **Chiffrement AES-256-GCM** des numéros de carte au repos (`cryptoService.js`).
- **Helmet**, **CORS** restreint, **rate limiting** (global + strict sur l'authentification).
- **Validation Joi** stricte sur tous les payloads entrants.
- **Transactions ACID** : les virements utilisent `db.transaction()` (SQLite) pour un débit/crédit atomique.
- **Scoring de fraude** à base de règles : montant, fréquence, nouveauté du bénéficiaire, ancienneté du compte ; au-delà d'un seuil, la transaction passe en revue manuelle (back-office).

## ⚡ Temps réel

Le solde des comptes, les nouvelles transactions et les messages du chatbot sont poussés
en direct via **Socket.io** (room privée `user:{id}`) — testez en ouvrant deux onglets connectés
au même compte et en effectuant un virement.

## 🧩 Fonctionnalités par module

| Module | Détails |
|---|---|
| **Espace Client** | Onboarding KYC simulé, dashboard temps réel, multi-comptes/devises (EUR/USD/GBP) |
| **Opérations Financières** | Virement instantané (IBAN ou téléphone), prélèvements planifiés (cron horaire), catégorisation budgétaire automatique (regex) |
| **Sécurité** | TOTP 2FA, chiffrement AES-256-GCM, cartes virtuelles éphémères (24h) |
| **Support & Admin** | Chatbot avec escalade humaine, back-office RBAC (validation KYC, revue fraude, suspension de compte) |

## 🛠️ Remplacer les services simulés par de vraies intégrations

- `backend/src/services/kycService.js` → SDK Sumsub/Onfido (webhook de validation)
- `backend/src/services/chatbotService.js` → appel à l'API OpenAI/LangChain
- Agrégation Open Banking (Plaid/Bridge) → à ajouter dans `services/` + route dédiée
- SQLite → PostgreSQL : adapter `config/database.js` (les requêtes SQL restent quasi identiques)

## 📦 Base de données

SQLite fichier local (`backend/neobank.sqlite`, généré automatiquement, ignoré par git).
Tables : `users`, `accounts`, `cards`, `transactions`, `scheduled_payments`, `chat_messages`, `audit_logs`.

## ✅ Tests effectués (backend validé de bout en bout)

- Inscription + connexion + rafraîchissement de token
- RBAC (un client ne peut pas accéder aux routes `/api/admin/*` → 403)
- Virement instantané avec débit/crédit atomique et mise à jour du solde
- Création de carte virtuelle + chiffrement/déchiffrement du numéro
- Catégorisation budgétaire automatique
- Chatbot avec réponse contextuelle et détection d'escalade
- Proxy Vite frontend ↔ backend (API + WebSocket)
